package com.assessment.web.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.assessment.common.CommonUtil;
import com.assessment.common.Qualifiers;
import com.assessment.common.util.NavigationConstants;
import com.assessment.data.CandidateProfileParams;
import com.assessment.data.License;
import com.assessment.data.QuestionMapperInstance;
import com.assessment.data.TestLinkTime;
import com.assessment.data.User;
import com.assessment.repositories.CandidateProfileParamsRepository;
import com.assessment.repositories.LicenseRepository;
import com.assessment.repositories.QuestionMapperInstanceRepository;
import com.assessment.repositories.QuestionRepository;
import com.assessment.repositories.TestLinkTimeRepository;
import com.assessment.services.CandidateProfileParamsService;
import com.assessment.services.LicenseService;
import com.assessment.services.TestLinkTimeService;
import com.assessment.services.TestService;

@Controller
public class MiscellaneousController {

	@Autowired
	LicenseService licenseService;

	@Autowired
	QuestionMapperInstanceRepository questionMapperInstanceRepository;
	
	@Autowired
	TestLinkTimeService testLinkService;
	
	@Autowired
	TestService testService;
	
	@Autowired
	QuestionRepository questionRepository;
	
	@Autowired
	CandidateProfileParamsService profileService;
	
	@Autowired
	CandidateProfileParamsRepository paramsRepository;
	
	@Autowired
	TestLinkTimeRepository testLinkTimeRepository;
	
	@Autowired
	LicenseRepository licenseRepository;
	
	@GetMapping("/newDomainReport")
	public ModelAndView filterreport(HttpServletRequest request) {
		ModelAndView mav = new ModelAndView("newDomainReport");
	
		return mav;
	}
	
	@RequestMapping(value = "/newLicenses", method = RequestMethod.GET)
	public ModelAndView newLicenses(String msgType, String icon, String msg, @RequestParam(name= "page", required = false) Integer pageNumber, HttpServletRequest request, HttpServletResponse response, ModelMap modelMap) throws Exception {
		ModelAndView mav = new ModelAndView("newLicenses");
		
		if(pageNumber == null) {
			pageNumber = 0;
		}
		License license = new License(); 
		User user = (User) request.getSession().getAttribute("user");
		Page<License> licenses = licenseService.getLicenses(user.getCompanyId(), PageRequest.of(pageNumber, NavigationConstants.NO_LICENSES_PAGE));
		mav.addObject("licenses", licenses.getContent());
		CommonUtil.setCommonAttributesOfPagination(licenses, modelMap, pageNumber, "licenses", null);
			if(msgType != null && msg != null){
				mav.addObject("message", msg);// later put it as label
				mav.addObject("msgtype", msgType);
				mav.addObject("icon", icon);
			}
			mav.addObject("license", license);
		return mav;
	}
	
	@RequestMapping(value = "/newSavelicense", method = RequestMethod.POST)
	public ModelAndView newSavelicense(@ModelAttribute("license") License license,  HttpServletRequest request, HttpServletResponse response, ModelMap modelMap) throws Exception {
		User user = (User) request.getSession().getAttribute("user");
			if(license.getId() == null){
				//check if name is distinct and one of saved
				License lic = licenseService.findByPrimaryKey(license.getLicenseName(), user.getCompanyId());
				if(lic != null){
					return newLicenses("Information" ,"warning","License "+license.getLicenseName()+" can not be saved. Use a different license name. ", 0, request, response, modelMap);
				}
			}
		license.setCompanyId(user.getCompanyId());
		license.setCompanyName(user.getCompanyName());
		licenseService.saveOrUpdate(license);
		return newLicenses("Information","success", "License "+license.getLicenseName()+" saved.", 0, request, response, modelMap);
	}
	
	@RequestMapping(value = "/searchLicenses", method = RequestMethod.GET)
	public ModelAndView searchLicenses(@RequestParam(name= "page", required = false) Integer pageNumber,@RequestParam String searchText, HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView("newLicenses");
		if(pageNumber == null) {
			pageNumber = 0;
		}
		License license = new License(); 
		User user = (User) request.getSession().getAttribute("user");
		Page<License> licenses = licenseRepository.searchLicenses(user.getCompanyId(), searchText,PageRequest.of(pageNumber, NavigationConstants.NO_LICENSES_PAGE));
		mav.addObject("licenses", licenses.getContent());
		CommonUtil.setCommonAttributesOfPagination(licenses, mav.getModelMap(), pageNumber, "searchLicenses", null);
		mav.addObject("license", license);
		return mav;
	}
	
	@RequestMapping(value = "/editLicense", method = RequestMethod.GET)
	@ResponseBody
	public Map<String,Object> editLicense(@RequestParam(name= "id", required = false) Long id, HttpServletRequest request ){
		Map<String,Object> map = new HashMap<>();
		License license = licenseRepository.findById(id).get();
		map.put("license", license);
		return map;
	}
	
	@RequestMapping(value = "/newSingleFileSessions", method = RequestMethod.GET)
	public ModelAndView newSingleFileSessions(@RequestParam(name= "page", required = false) Integer pageNumber, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView("newSingle_file_results");
		User user = (User) request.getSession().getAttribute("user");
		if(pageNumber == null) {
			pageNumber = 0;
		}
		Page<QuestionMapperInstance> questionMapperInstances = questionMapperInstanceRepository.findCodingQuestionMapperInstances(user.getCompanyId(), PageRequest.of(pageNumber, NavigationConstants.NO_SIGLEFILE_PAGE));
		
  		mav.addObject("answers", questionMapperInstances.getContent());
		CommonUtil.setCommonAttributesOfPagination(questionMapperInstances, mav.getModelMap(), pageNumber, "newSingleFileSessions", null);
		return mav;
	}
	
	@RequestMapping(value = "/searchSingleFileSessions", method = RequestMethod.GET)
	public ModelAndView searchSingleFileSessions(@RequestParam(name= "page", required = false) Integer pageNumber,@RequestParam String searchText, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView("newSingle_file_results");
		User user = (User) request.getSession().getAttribute("user");
		if(pageNumber == null) {
			pageNumber = 0;
		}
		Page<QuestionMapperInstance> questionMapperInstances = questionMapperInstanceRepository.searchCodingQuestionMapperInstances(user.getCompanyId(), searchText,PageRequest.of(pageNumber, NavigationConstants.NO_SIGLEFILE_PAGE));
		
  		mav.addObject("answers", questionMapperInstances.getContent());
		CommonUtil.setCommonAttributesOfPagination(questionMapperInstances, mav.getModelMap(), pageNumber, "searchSingleFileSessions", null);
		return mav;
	}
	
	@RequestMapping(value = "/newListTestLinks", method = RequestMethod.GET)
	public ModelAndView newListTenants(@RequestParam(name= "page", required = false) Integer pageNumber, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView("newList_link");
		User user = (User) request.getSession().getAttribute("user");
		if(pageNumber == null) {
			pageNumber = 0;
		}
		List<String> tests = testService.getTestNames(user.getCompanyId());
		mav.addObject("tests", tests);
		TestLinkTime testLinkTime=new TestLinkTime();
		mav.addObject("link", testLinkTime);
		Page<TestLinkTime> testlinks = testLinkService.findAllLinks(PageRequest.of(pageNumber, NavigationConstants.NO_TESTLINK_PAGE));
		mav.addObject("links", testlinks.getContent());
		CommonUtil.setCommonAttributesOfPagination(testlinks, mav.getModelMap(), pageNumber, "newListTestLinks", null);
		return mav;
	}
	
	@RequestMapping(value = "/newSaveTestLink", method = RequestMethod.POST)
	public ModelAndView newSaveTestLink(HttpServletRequest request, HttpServletResponse response, @ModelAttribute("link") TestLinkTime link) throws Exception {
		ModelAndView mav = new ModelAndView("newList_link");
		User user = (User) request.getSession().getAttribute("user");
		
			link.setCompanyId(user.getCompanyId());
			link.setCompanyName(user.getCompanyName());
			com.assessment.data.Test test = testService.findbyTest(link.getTestName(), user.getCompanyId());
			link.setTestId(test.getId());
		testLinkService.saveOrUpdate(link);
		mav.addObject("message", "Public Test Link for test - "+link.getTestName()+"!!!");// later put it as label
		mav.addObject("msgtype", "success");
		mav.addObject("icon", "success");
		Integer pageNumber = 0;
		List<String> tests = testService.getTestNames(user.getCompanyId());
		mav.addObject("tests", tests);
		Page<TestLinkTime> testlinks = testLinkService.findAllLinks(PageRequest.of(pageNumber, 15));
		mav.addObject("links", testlinks.getContent());
		CommonUtil.setCommonAttributesOfPagination(testlinks, mav.getModelMap(), pageNumber, "newListTestLinks", null);
		return mav;
	}
	
	@RequestMapping(value = "/searchTestLinks", method = RequestMethod.GET)
	public ModelAndView searchTestLinks(@RequestParam(name= "page", required = false) Integer pageNumber, @RequestParam String searchText,HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView("newList_link");
		User user = (User) request.getSession().getAttribute("user");
		if(pageNumber == null) {
			pageNumber = 0;
		}
		List<String> tests = testService.getTestNames(user.getCompanyId());
		mav.addObject("tests", tests);
		TestLinkTime testLinkTime=new TestLinkTime();
		mav.addObject("link", testLinkTime);
		Page<TestLinkTime> testlinks =testLinkTimeRepository.findTestLink(user.getCompanyId(), searchText, PageRequest.of(pageNumber, NavigationConstants.NO_TESTLINK_PAGE)); 
		mav.addObject("links", testlinks.getContent());
		CommonUtil.setCommonAttributesOfPagination(testlinks, mav.getModelMap(), pageNumber, "searchTestLinks", null);
		return mav;
	}
	
	@RequestMapping(value = "/getLinkById", method = RequestMethod.GET)
	@ResponseBody
	public Map<String,Object> getLinkById(@RequestParam(name= "id", required = false) Long id, HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String,Object> map = new HashMap<>();
		 TestLinkTime linkTime = testLinkTimeRepository.findById(id).get();
		 map.put("link", linkTime);
		return map;
	}
	
	
	@RequestMapping(value = "/recomms", method = RequestMethod.GET)
	public ModelAndView recomms(HttpServletRequest request, HttpServletResponse response,@RequestParam(name= "character", required = false) String character,@RequestParam(name= "msg", required = false) String msg ) throws Exception {
		ModelAndView mav = new ModelAndView("recomms");
		User user = (User) request.getSession().getAttribute("user");
		char c;
		List<String> characters = new ArrayList<>();
		  for(c = 'A'; c <= 'Z'; ++c) {
		            System.out.print(c + " ");
		            characters.add(Character.toString(c));
		  }
		  mav.addObject("characters", characters);
		  if(character==null) {
			  character="A";
		  }
		  if(msg!=null) {
			 mav.addObject("message", msg);// later put it as label
			mav.addObject("msgtype", "Information");
			mav.addObject("icon", "success");
		  }
		  List<CandidateProfileParams> params =  paramsRepository.findCandidateProfileParamsByCharacter(user.getCompanyId(), character);
		  mav.addObject("params", params);
		Set<Qualifiers> qualifiers = questionRepository.getAllUniqueQualifiers(user.getCompanyId());
		mav.addObject("selected", character);
		mav.addObject("params2", new CandidateProfileParams());
		mav.addObject("qualifiers", qualifiers);
		return mav;
	}
	
	@RequestMapping(value = "/getProfileParams", method = RequestMethod.GET)
	@ResponseBody
	public Map<String,Object> getProfileParams(HttpServletRequest request, HttpServletResponse response,@RequestParam(name= "qual", required = false) String qual ) throws Exception {
		Map<String,Object> map = new HashMap<>();
		User user = (User) request.getSession().getAttribute("user");
		if(qual != null){
			String qls[] = qual.split("-");
			CandidateProfileParams params = profileService.findUniqueCandidateProfileParams(user.getCompanyId(), qls[0], qls[1], qls[2], qls[3], qls[4]);
			if(params == null){
				params = new CandidateProfileParams(qls[0], qls[1], qls[2], qls[3], qls[4]);
			}
			params.setContext(qual);
			map.put("params3", params);
		}
		return map;
	}
	
	@RequestMapping(value = "/newSaveProfileParams", method = RequestMethod.POST)
	    public ModelAndView  newSaveProfileParams(@ModelAttribute("params") CandidateProfileParams params, HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView("recomm");
		 User user = (User) request.getSession().getAttribute("user");
		 params.setCompanyId(user.getCompanyId());
		 params.setCompanyName(user.getCompanyName());
		 profileService.saveOrUpdate(params);
		 String character = "A";
		 String msg="Save Success";
	 	 return recomms(request, response, character,msg);
	    }
	
}
